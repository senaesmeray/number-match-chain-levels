# Number Match – Chain Levels

Number Match (Take Ten) prototipi: şekilli tahtalar + opsiyonel 3'lü zincir eşleşme.
12 level, hepsi solver ile doğrulandı — hem 2'li hem zincirli kuralla, + butonu olmadan çözülebilir.
